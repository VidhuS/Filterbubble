$(document).ready(function(){
	AOS.init();
});